﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.IO;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ezafeladatremelemertekeliazelszantsagotminimumkettes
{
    /// <summary>
    /// Interaction logic for StatisztikakWindow.xaml
    /// </summary>
    public partial class StatisztikakWindow : Window
    {
        private const string TeamsFile = "teams.txt";
        private const string PlayersFile = "players.txt";
        private const string MatchesFile = "matches.txt";

        public StatisztikakWindow()
        {
            InitializeComponent();
            FrissitStatisztikak();
        }

        private void FrissitButton_Click(object sender, RoutedEventArgs e)
        {
            FrissitStatisztikak();
        }

        private void FrissitStatisztikak()
        {
            // Csapat statisztikák
            if (File.Exists(TeamsFile))
            {
                List<string> csapatok = new List<string>(File.ReadAllLines(TeamsFile));
                List<string> csapatStatisztikak = new List<string>();

                foreach (string csapat in csapatok)
                {
                    int jatekosokSzama = 0;
                    if (File.Exists(PlayersFile))
                    {
                        jatekosokSzama = File.ReadAllLines(PlayersFile)
                            .Count(line => line.StartsWith(csapat + ";"));
                    }

                    csapatStatisztikak.Add($"{csapat} - Játékosok: {jatekosokSzama}");
                }

                lbCsapatStatisztikak.ItemsSource = csapatStatisztikak;
            }

            // Játékosok
            if (File.Exists(PlayersFile))
            {
                List<string> jatekosok = new List<string>(File.ReadAllLines(PlayersFile));
                lbJatekosok.ItemsSource = jatekosok;
            }

            // Mérkőzések
            if (File.Exists(MatchesFile))
            {
                List<string> merkozesek = new List<string>(File.ReadAllLines(MatchesFile));
                lbMerkozesek.ItemsSource = merkozesek;
            }
        }

        private void BezarButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
