﻿using ezafeladatremelemertekeliazelszantsagotminimumkettes;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ezafeladatremelemertekeliazelszantsagotminimumkettes
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void CsapatokButton_Click(object sender, RoutedEventArgs e)
        {
            CsapatokWindow csapatokWindow = new CsapatokWindow();
            csapatokWindow.ShowDialog();
        }

        private void CsapattagokButton_Click(object sender, RoutedEventArgs e)
        {
            CsapattagokWindow csapattagokWindow = new CsapattagokWindow();
            csapattagokWindow.ShowDialog();
        }

        private void MerkozesButton_Click(object sender, RoutedEventArgs e)
        {
            MerkozesWindow merkozesWindow = new MerkozesWindow();
            merkozesWindow.ShowDialog();
        }

        private void StatisztikakButton_Click(object sender, RoutedEventArgs e)
        {
            StatisztikakWindow statisztikakWindow = new StatisztikakWindow();
            statisztikakWindow.ShowDialog();
        }
    }
}