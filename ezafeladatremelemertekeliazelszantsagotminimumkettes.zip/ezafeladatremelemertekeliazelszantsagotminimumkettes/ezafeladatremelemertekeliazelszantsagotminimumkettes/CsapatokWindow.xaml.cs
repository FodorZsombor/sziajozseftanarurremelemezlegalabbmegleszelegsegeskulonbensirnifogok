﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.IO;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ezafeladatremelemertekeliazelszantsagotminimumkettes
{
    /// <summary>
    /// Interaction logic for CsapatokWindow.xaml
    /// </summary>
    public partial class CsapatokWindow : Window
    {
        private const string TeamsFile = "teams.txt";

        public CsapatokWindow()
        {
            InitializeComponent();
            BetoltCsapatok();
        }

        private void HozzaadButton_Click(object sender, RoutedEventArgs e)
        {
            string csapatNev = txtCsapatNev.Text.Trim();
            if (!string.IsNullOrEmpty(csapatNev))
            {
                File.AppendAllText(TeamsFile, csapatNev + "\n");
                txtCsapatNev.Clear();
                BetoltCsapatok();
                MessageBox.Show("Csapat hozzáadva!");
            }
        }

        private void BetoltButton_Click(object sender, RoutedEventArgs e)
        {
            BetoltCsapatok();
        }

        private void BetoltCsapatok()
        {
            if (File.Exists(TeamsFile))
            {
                List<string> csapatok = new List<string>(File.ReadAllLines(TeamsFile));
                lbCsapatok.ItemsSource = csapatok;
            }
        }

        private void BezarButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
